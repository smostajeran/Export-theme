// This is the javascript entrypoint for the video-modal component.
// This file and all its inclusions will be processed through postcss

import '@archetype-themes/scripts/config'
