// This is the javascript entrypoint for the featured-collection section.
// This file and all its inclusions will be processed through postcss

import '@archetype-themes/scripts/config';
import '@archetype-themes/scripts/modules/collection-template';
