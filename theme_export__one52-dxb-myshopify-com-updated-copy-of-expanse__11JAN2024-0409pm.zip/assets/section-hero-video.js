// This is the javascript entrypoint for the hero-video section.
// This file and all its inclusions will be processed through esbuild

import '@archetype-themes/scripts/config';
import "@archetype-themes/scripts/modules/video-section";
