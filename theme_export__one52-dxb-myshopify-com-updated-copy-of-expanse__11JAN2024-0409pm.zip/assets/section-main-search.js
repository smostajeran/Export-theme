// This is the javascript entrypoint for the main-search section.
// This file and all its inclusions will be processed through esbuild

import '@archetype-themes/scripts/config';
import '@archetype-themes/scripts/helpers/utils';
import '@archetype-themes/scripts/helpers/ajax-renderer';
import '@archetype-themes/scripts/modules/collection-template';
