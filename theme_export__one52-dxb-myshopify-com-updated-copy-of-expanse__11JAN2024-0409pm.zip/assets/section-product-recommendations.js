// This is the javascript entrypoint for the product-recommendations section.
// This file and all its inclusions will be processed through esbuild

import '@archetype-themes/scripts/modules/product-recommendations';

