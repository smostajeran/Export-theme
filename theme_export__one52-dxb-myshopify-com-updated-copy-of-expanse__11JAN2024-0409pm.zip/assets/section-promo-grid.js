// This is the javascript entrypoint for the promo-grid section.
// This file and all its inclusions will be processed through postcss

import '@archetype-themes/scripts/config';
import '@archetype-themes/scripts/modules/video-section';
